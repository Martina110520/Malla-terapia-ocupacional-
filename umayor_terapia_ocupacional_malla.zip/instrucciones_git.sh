#!/bin/bash
# Instrucciones rápidas para crear un repo en GitHub y subir estos archivos.
# 1) Crea un nuevo repo en GitHub (p. ej. 'malla-terapia-ocupacional-umayor')
# 2) Ejecuta los comandos abajo en tu máquina (ajusta usuario y repo)

git init
git add .
git commit -m "Malla curricular - Terapia Ocupacional (Universidad Mayor) - transcripción inicial"
# Reemplaza USER y REPO por tu usuario y repo
git branch -M main
git remote add origin https://github.com/USER/REPO.git
git push -u origin main

# Si quieres crear el repo desde la CLI de GitHub (gh):
# gh repo create USER/REPO --public --source=. --remote=origin --push
