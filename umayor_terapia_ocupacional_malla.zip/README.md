# Malla curricular - Terapia Ocupacional (Universidad Mayor, Chile)

Este repositorio contiene una transcripción de la **malla curricular** de la carrera **Terapia Ocupacional** de la **Universidad Mayor (sede Santiago / Temuco)**, en formato listo para publicar en GitHub.

**Fuente oficial (malla):**
- Universidad Mayor — Malla curricular Terapia Ocupacional (PDF). Fuente: Universidad Mayor. Consulte el documento oficial para nombres y créditos exactos. Referencia: https://www.umayor.cl/um/bundles/umayor/descargables/mallas/terapia-ocupacional-santiago-umayor.pdf. (ver también la página de la carrera en https://www.umayor.cl/um/carreras/terapia-ocupacional-santiago)

---

## Contenido del repositorio
- `malla.md` : Malla organizada por semestres (formato legible).
- `curriculum.csv` : Tabla con dos columnas: "Semestre" y "Cursos" (los cursos están separados por `|`).
- `instrucciones_git.sh` : Script con comandos para crear un repo en GitHub y subir estos archivos.

---

## Aviso
Esta transcripción se realizó a partir de la malla pública de la Universidad Mayor. **Revisa la versión oficial** en la fuente citada para confirmar nombres exactos de asignaturas, créditos (SCT) y actualización de la malla.
