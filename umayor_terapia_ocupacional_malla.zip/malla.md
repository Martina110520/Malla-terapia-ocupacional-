# Malla curricular - Terapia Ocupacional (Universidad Mayor)

## Semestre 1

- Desarrollo personal y autoconocimiento
- Fundamentos de Terapia Ocupacional
- Estudios en ocupación y Terapia Ocupacional
- Anatomía humana
- Psicología en el curso de la vida
- Biología celular e histoembriología

## Semestre 2

- Participación ocupacional I
- Desarrollo de la creatividad
- Filosofía de la ocupación
- Anatomía funcional y biomecánica I
- Ciencias sociales para la terapia ocupacional
- Fisiología general

## Semestre 3

- Participación ocupacional II
- Razonamiento situado y estrategias terapéuticas I
- Salud basada en la evidencia
- Anatomía funcional y biomecánica II
- Gerontología social y ocupación
- Fisiopatología

## Semestre 4

- Práctica integrada inicial
- Enfoques y modelos de práctica
- Desarrollo de la persona del terapeuta
- Psicomotricidad en el curso de la vida
- Neurociencias aplicadas

## Semestre 5

- Participación ocupacional e inclusión
- Razonamiento situado y estrategias terapéuticas II
- Diseños de investigación cuantitativa
- Procesos de salud y enfermedad en niñez y juventud
- Procesos de salud y enfermedad en adultez y personas mayores
- Salud pública
- Bioética

## Semestre 6

- Práctica integrada y perspectiva situada
- Diseños de investigación cualitativa
- Desafíos ocupacionales en infancia y juventud
- Desafíos ocupacionales en adultez y personas mayores
- Terapia ocupacional en rehabilitación física (contenidos aplicados)
- Ortótica y tecnología aplicada I

## Semestre 7

- Proceso de terapia ocupacional en comunidad
- Ortótica y tecnología aplicada I (continuación)
- Ergonomía aplicada a la ocupación
- Proceso de terapia ocupacional en niñez y juventud
- Emprendimiento e innovación

## Semestre 8

- Práctica integrada y sistematización
- Ortótica y tecnología aplicada II
- Proyecto aplicado de investigación
- Práctica integrada en niñez y juventud
- Inteligencia artificial aplicada a la salud

## Semestre 9

- Práctica profesional I
- Práctica profesional II
- Desarrollo profesional I
- Proyecto de título I

## Semestre 10

- Práctica profesional III
- Práctica profesional IV
- Desarrollo profesional II
- Proyecto de título II
- Trabajo de título / Examen de título
